CREATE TABLE `country` (
    `countryid` bigint NOT NULL,
    `countryname` varchar(50) NOT NULL,
    `state_name` varchar(50) NOT NULL
)

CREATE TABLE 'states' (
    
)