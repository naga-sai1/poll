// module.exports = (sequelize, DataTypes) => {
//     return sequelize.define(
//       "booths",
//       {
//         booth_pk: {
//           type: DataTypes.INTEGER,
//           primaryKey: true,
//           autoIncrement: true,
//         },
//         booth_no: DataTypes.INTEGER,
//         sachivalayam_pk: {
//             type: DataTypes.INTEGER,
//             primaryKey: true,
//         },
//         booth_name: DataTypes.STRING,
//         booth_fulladdress: DataTypes.TEXT,
//       },

//       {
//         tableName: "booths",
//         engine: "InnoDB",
//         timestamps: false,
//       }
//     );
//   };
