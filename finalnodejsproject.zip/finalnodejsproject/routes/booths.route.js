// const express = require("express");
// const controller = require("../controllers/booths.controller.js");
// const router = express.Router();
// router.get("/booths/getall", controller.getAll);
// router.get("/booths/:id", controller.getById);
// router.post("/booths/", controller.create);
// router.put("/booths/:id", controller.updateById);
// router.delete("/booths/:id", controller.deletedById);

// module.exports = router;
